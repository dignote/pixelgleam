# PIXELGLEAM — ALL 7 ARTWORKS MASTER QA REPORT

- Butterfly Bloom: STATUS PASS | colors 14 | cells 369 | regions 167 | coverage 100.0%
- Aurora Mandala: STATUS PASS | colors 15 | cells 429 | regions 280 | coverage 100.0%
- Hummingbird Hibiscus: STATUS PASS | colors 15 | cells 349 | regions 154 | coverage 100.0%
- Matcha Tea Set: STATUS PASS | colors 12 | cells 359 | regions 160 | coverage 100.0%
- Rainy Bookshop: STATUS PASS | colors 14 | cells 408 | regions 181 | coverage 100.0%
- Sakura Cat Window: STATUS PASS | colors 13 | cells 393 | regions 182 | coverage 100.0%
- Forest Witch: STATUS PASS | colors 15 | cells 412 | regions 211 | coverage 100.0%